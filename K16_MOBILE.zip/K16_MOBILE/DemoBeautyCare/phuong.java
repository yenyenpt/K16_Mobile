let name = "Phuong"
console.log("Hi" + name)
