let name = "Chu chuong"
console.log("Xin chao"+name)
