const express = require('express')
const app = express() //Tao ra mot ung dung Web Express

const http = require('http')
const server = http.createServer(app)

//Tao ra 1 socket server 
const {Server} = require("socket.io")
const io = new Server(server)//tao ra 1 socket.io

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});
app.get('/xinchao1', (req, res) => {
    res.sendFile(__dirname + '/xinchao.html');
});


//Tren server socket thi lang nghe su kien connection
io.on('connection', (socket) => {
    console.log('Co mot nguoi vua ket noi toi Socket server');
    socket.on('gui_tin_nhan', (data) => {
        console.log("Client vua gui tin nhan co noi dung la: " + data)
        socket.emit('gui_chau', "Anh yeu em:  " + data)
    })

    socket.on('mobile_k16', (data) => {
        console.log("Nhom K16 co tin nhan moi: " + data)
        socket.emit("k16_tinhanmoi", data)
    })
})

server.listen(3000, () => {
    console.log('listening on *:3000');
});

