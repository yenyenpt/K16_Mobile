var account = {
    email: 'khactuan@gmail.com',
    password: 'tuan123'
}
function validateEmail () {
    var email = document.getElementById("emailInput")
    if(email.value == account.email) {
        return true;
    } else {
        return false;
    }
}
function validatePass () {
    var password = document.getElementById("passInput")
    if(password.value == account.password) {
        return true;
    } else {
        return false;
    }
}
function login () {
    const isEmail = validateEmail();
    const isPassword = validatePass();
    if(isEmail && isPassword) {
        window.location.href = "home.html";
    }else {
        alert("Tài Khoản hoặc mật khẩu không đúng");
    }
}

function backLogin () {
    window.location.href = "login.html";
}

function loginFaild() {
    alert("Tài Khoản hoặc mật khẩu không đúng");
}