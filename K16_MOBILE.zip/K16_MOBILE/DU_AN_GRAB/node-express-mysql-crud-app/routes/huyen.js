const express = require("express");
const router = express.Router();
const{
    readHuyen
} = require("../controllers/huyen");

router.get("/huyen",readHuyen);
module.exports = router;