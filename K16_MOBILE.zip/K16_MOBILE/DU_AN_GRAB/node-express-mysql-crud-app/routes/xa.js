const express = require("express");
const router = express.Router();
const{
    readXa,
} = require("../controllers/xa");

router.get("/xa",readXa);
module.exports = router;