const express = require("express");
const router = express.Router();
const {
  createUser,
  readUser,
  updateUser,
  deleteUser,
} = require("../controllers/user");

router.post("/user", createUser);// tao tk user

router.get("/user", readUser);//lấy ra danh sach các user

router.put("/user/:userId", updateUser);// cập nhật thông tin user

router.delete("/user/:userId", deleteUser);// xoá 1 user

module.exports = router;
