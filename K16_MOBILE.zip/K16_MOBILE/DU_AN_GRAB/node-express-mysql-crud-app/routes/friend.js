const express = require("express");
const router = express.Router();
const {
  createFriend,
  readFriend,
  updateFriend,
  deleteFriend,
} = require("../controllers/friend");

router.post("/friend", createFriend);// tao tk user

router.get("/friend", readFriend);//lấy ra danh sach các user

router.put("/friend/:friendId", updateFriend);// cập nhật thông tin user

router.delete("/friend/:friendId", deleteFriend);// xoá 1 user

module.exports = router;