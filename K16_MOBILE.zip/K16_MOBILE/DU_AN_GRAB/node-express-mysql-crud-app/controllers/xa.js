const Xa = require("../models/xa");

exports.readXa = async (req, res) => {
    Xa.read(function (err, xa) {
    if (err) {
      return res.status(403).send(err);
    }
    res.json(xa);
  });
};
