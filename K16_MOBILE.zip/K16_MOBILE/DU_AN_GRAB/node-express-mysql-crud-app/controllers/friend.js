const Friend = require("../models/friend");

exports.createFriend = async (req, res) => {
  if (!req.body.firstName || !req.body.lastName || !req.body.email) {
    return res.status(422).json({
      firstName: "firstname is required",
      lastName: "firstname is required",
      email: "email is required",
    });
  }
  const friend = new Friend(req.body);
  Friend.create(friend, function (err, friend) {
    if (err) {
      return res.status(403).send(err);
    }
    res.json(friend);
  });
};

exports.readFriend = async (req, res) => {
    Friend.read(function (err, friend) {
    if (err) {
      return res.status(403).send(err);
    }
    res.json(friend);
  });
};

exports.updateFriend = async (req, res) => {
  const id = req.params.friendId;
  Friend.update(id, new Friend(req.body), function (err, friend) {
    if (err) {
      return res.status(403).send(err);
    }
    res.json(friend);
  });
};

exports.deleteFriend = async (req, res) => {
  const id = req.params.friendId;
  Friend.delete(id, function (err, friend) {
    if (err) {
      return res.status(403).send(err);
    }
    res.json(friend);
  });
};