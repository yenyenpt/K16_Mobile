const Huyen = require("../models/huyenj");

exports.readHuyen = async (req, res) => {
    Huyen.read(function(err, huyen){
        if(err){
            return res.status(403).send(err);
        }
        res.json(huyen);
    });
};