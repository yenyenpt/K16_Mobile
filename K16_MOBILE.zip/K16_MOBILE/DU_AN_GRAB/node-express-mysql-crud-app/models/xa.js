const Xa = function (xa){
    this.idXa = xa.idXa;
    this.tenXa = xa.tenXa;
}
Xa.read = function (result) {
    connection.query("SELECT ten_xa FROM xa", (err, res) => {
      if (err) {
        result(err, null);
      } else {
        result(null, res);
      }
    });
  };
  module.exports = Xa;