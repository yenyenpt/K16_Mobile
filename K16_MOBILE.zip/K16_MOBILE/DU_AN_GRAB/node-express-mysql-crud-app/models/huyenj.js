"huyenj strict";

const Huyen = function(huyen){
    this.idHuyen = huyen.idHuyen;
    this.tenHuyen = huyen.tenHuyen;
}
Huyen.read = function(result){
    connection.query("Select ten_huyen From huyen",(err,res) =>{
        if(err){
            result(err,null);

        }else{
            result(null,res);
        }
        
    });
};
module.exports = Huyen;