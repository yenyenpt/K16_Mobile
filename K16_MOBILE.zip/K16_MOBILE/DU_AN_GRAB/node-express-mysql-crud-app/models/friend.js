const Friend = function (friend) {
    this.firstName = friend.firstName;
    this.lastName = friend.lastName;
    this.email = friend.email;
    this.createdAt = new Date();
    this.updatedAt = new Date();
  };
  
  Friend.create = function (friend, result) {
    connection.query("INSERT INTO friends set ?", friend, function (err, res) {
      if (err) {
        result(err, null);
      } else {
        result(null, res.insertId);
      }
    });
  };
  
  Friend.read = function (result) {
    connection.query("SELECT * FROM friends", (err, res) => {
      if (err) {
        result(err, null);
      } else {
        result(null, res);
      }
    });
  };
  
  Friend.update = function (id, friend, result) {
    connection.query("UPDATE friends SET ? WHERE _id = ?", [friend, id], function (
      err,
      res
    ) {
      if (err) {
        result(null, err);
      } else {
        result(null, res);
      }
    });
  };
  
  Friend.delete = function (id, result) {
    connection.query("DELETE FROM friends WHERE _id = ?", [id], function (
      err,
      res
    ) {
      if (err) {
        result(null, err);
      } else {
        result(null, res);
      }
    });
  };
  
  module.exports = Friend;