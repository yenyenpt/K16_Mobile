const express = require('express') // B1:import vào thư viện
const app = express() // tạo ra ứng dựng web sử dụng thư viện express
const port = 3000 // tạo port 3000

app.get('/', (req, res) => //tạo API phương thức GET có đường dẫn là localhost
{
  res.send('Hello World!')
})

app.listen(port, () => // Mở port 3000 và bắt đầu server đó
{
  console.log(`Example app listening on port ${port}`)
})