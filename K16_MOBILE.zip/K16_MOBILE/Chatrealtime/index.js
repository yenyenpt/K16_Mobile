const express = require('express');
const app = express();
const http = require('http');
const server = http.createServer(app);

app.get('/', (req, res) => {//http://localhost:3000/ -> GET
  res.send('<h1>Hello world</h1>');
});

server.listen(3000, () => { //port: cổng IP: 192.168.0.1:3000
  console.log('listening on *:3000');
});
