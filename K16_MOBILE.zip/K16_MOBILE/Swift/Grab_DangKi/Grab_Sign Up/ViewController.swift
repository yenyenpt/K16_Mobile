//
//  ViewController.swift
//  Grab_Sign Up
//
//  Created by yenyen on 06/12/2022.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {
 

    @IBOutlet weak var txtAdress: UITextField!
    @IBOutlet weak var txtXa: UITextField!

  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.txtXa.delegate=self
        
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return txtXa.resignFirstResponder()
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
}

