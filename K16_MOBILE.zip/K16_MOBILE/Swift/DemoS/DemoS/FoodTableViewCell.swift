//
//  FoodTableViewCell.swift
//  DemoS
//
//  Created by yenyen on 17/09/2022.
//

import UIKit

class FoodTableViewCell: UITableViewCell {

    @IBOutlet weak var lblFoodName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }
    
}
