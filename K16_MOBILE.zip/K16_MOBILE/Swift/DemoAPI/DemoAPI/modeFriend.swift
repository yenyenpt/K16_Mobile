//
//  modeFriend.swift
//  DemoAPI
//
//  Created by yenyen on 15/11/2022.
//

import Foundation
struct FriendModel: Decodable {
    let createdAt, name: String
    let avatar: String
    let id: String
}

typealias Friend = [FriendModel]
