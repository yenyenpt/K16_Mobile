//
//  ViewController.swift
//  DemoAPI
//
//  Created by yenyen on 15/11/2022.
//

import UIKit
import Kingfisher
import Alamofire

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    var friends: Friend = []
    @IBOutlet weak var tblView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblView.delegate = self
        tblView.dataSource = self
        tblView.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "FriendIdentifier")
        getFriendFromAPT()
       
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return friends.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let currentFriend = friends[indexPath.row]
        let cell = tblView.dequeueReusableCell(withIdentifier: "FriendIdentifier",for: indexPath) as! TableViewCell
        let urlAvatar = URL(string: currentFriend.avatar)
        cell.imgFriend.kf.setImage(with: urlAvatar)
        
        cell.btnDelete.addTarget(self, action: #selector(deleteFriend(_:)), for: .touchUpInside)
        cell.btnDelete.tag = indexPath.row
        
        
        cell.lblFriendName.text = currentFriend.name
        cell.lblId.text = currentFriend.id
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    
    }
    
    
    @objc func deleteFriend(_ sender: UIButton){
        print("id:\(friends[sender.tag].id)")
        deleteFriend(_id:friends[sender.tag].id )
        
        friends.remove(at: sender.tag)
        self.tblView.reloadData()
    }
    
    func deleteFriend(_id: String){
        AF.request("https://6333cb15433198e79dc94f71.mockapi.io/Person/\(_id)",method: .delete).responseDecodable(of:Friend.self){
            response in
        }
    }
    
    func getFriendFromAPT(){
        AF.request("https://6333cb15433198e79dc94f71.mockapi.io/Person",method: .get).responseDecodable(of: Friend.self){
            responseData in
            if let friendData = responseData.value{
                self.friends = friendData
                self.tblView.reloadData()
            }
        }
    }
}

