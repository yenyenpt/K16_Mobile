//
//  ViewController.swift
//  API2
//
//  Created by yenyen on 15/11/2022.
//

import UIKit
import Kingfisher
import Alamofire

class ViewController: UIViewController ,UITableViewDelegate,UITableViewDataSource{
    var friends = 
    @IBOutlet weak var tblFriend: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblFriend.dataSource = self
        tblFriend.delegate = self
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        <#code#>
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        <#code#>
    }


}

