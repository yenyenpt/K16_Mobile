//
//  ViewController.swift
//  DemoZalo
//
//  Created by yenyen on 02/11/2022.
//

import UIKit
import MessageKit
import InputBarAccessoryView

class ViewController: MessagesViewController, MessagesDataSource, MessagesDisplayDelegate, MessagesLayoutDelegate,InputBarAccessoryViewDelegate {
    var messages: [ChatMessage] = []
    let yen = Sender(senderId: "ph02", displayName: "yen")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        messagesCollectionView.messagesDataSource = self
        messagesCollectionView.messagesLayoutDelegate = self
        messagesCollectionView.messagesDisplayDelegate = self
        messageInputBar.delegate = self
    }
    var currentSender: SenderType{
        return yen
    }
    
    
    func messageForItem(at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> MessageType {
        return messages[indexPath.section]
    }
    
    func numberOfSections(in messagesCollectionView: MessagesCollectionView) -> Int {
        return messages.count
    }
    
    func inputBar(_ inputBar: InputBarAccessoryView, didPressSendButtonWith text: String) {
        let currentMessages = ChatMessage(sender: yen, messageId: UUID().uuidString, sentDate: Date(), kind: .text(text))
        messages.append(currentMessages)
        messagesCollectionView.reloadData()
        inputBar.inputTextView.text = ""
    }
}


struct Sender : SenderType {
    var senderId: String
    
    var displayName: String
    

}
struct ChatMessage: MessageType{
    var sender: SenderType
    
    var messageId: String
    
    var sentDate: Date
    
    var kind: MessageKind
 
}


