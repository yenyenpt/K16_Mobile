//
//  ViewController.swift
//  BaiTapVeNha_Checkbox
//
//  Created by yenyen on 12/10/2022.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
 
    @IBOutlet weak var tblFriend: UITableView!
    
    var friends: Friend = []
    var friendDict: [Int: Bool] = [:]
    override func viewDidLoad() {
        super.viewDidLoad()
        tblFriend.delegate = self
        tblFriend.dataSource = self
        
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 100
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
    }
    
    
    
    


}
struct Friend{
    var String name;
    var String id;
    var
    
}

