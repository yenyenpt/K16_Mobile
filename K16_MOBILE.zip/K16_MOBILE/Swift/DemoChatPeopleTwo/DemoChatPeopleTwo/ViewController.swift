
import UIKit
import MessageKit
import InputBarAccessoryView

class ViewController: MessagesViewController,MessagesDataSource,MessagesDisplayDelegate,MessagesLayoutDelegate, InputBarAccessoryViewDelegate {
    
    var currentSender:SenderType {
        return yenNtSender
    }
    func messageForItem(at indexPath: IndexPath, in messagesCollectionView: MessageKit.MessagesCollectionView) -> MessageKit.MessageType {
        return messages [indexPath.section]
    }
    
    func numberOfSections(in messagesCollectionView: MessageKit.MessagesCollectionView) -> Int {
        return messages.count
    }
    
    let yenNtSender = Sender (senderId: "yenpt", displayName: "yen")
    let nhiSender = Sender (senderId: "nhipt", displayName: "nhi")
    var messages: [ChatMessage] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        messages.append(ChatMessage(sender: currentSender,
                                    messageId: "1",
                                    sentDate: Date(),
                                    kind: .photo(Media (url:nil,image: UIImage(named: "cuc"),placeholderImage: UIImage(named: "cuc")!,size: CGSize(width: 200, height: 100)))))
        messages.append(ChatMessage(sender: nhiSender,
                                    messageId: "1",
                                    sentDate: Date(),
                                    kind: .photo(Media (url:nil,image: UIImage(named: "trab"),placeholderImage: UIImage(named: "trab")!,size: CGSize(width: 200, height: 100)))))
        
        messagesCollectionView.messagesDataSource = self
        messagesCollectionView.messagesLayoutDelegate = self
        messagesCollectionView.messagesDisplayDelegate = self
        messageInputBar.delegate = self
    }
    func inputBar(_ inputBar: InputBarAccessoryView, didPressSendButtonWith text: String) {
        let currentMessges = ChatMessage (sender: yenNtSender, messageId: UUID().uuidString, sentDate: Date(), kind: .text(text) )
        messages.append(currentMessges)
        messagesCollectionView.reloadData()
        inputBar.inputTextView.text=""
    }
}
struct Sender: SenderType {
    var senderId: String
    var displayName: String
}

struct ChatMessage: MessageType {
    
    var sender: MessageKit.SenderType
    
    var messageId: String
    
    var sentDate: Date
    
    var kind: MessageKit.MessageKind
}

struct Media: MediaItem {
    var url: URL?
    var image: UIImage?
    var placeholderImage: UIImage
    var size: CGSize
}



