//
//  ViewController.swift
//  Grab_SignUp
//
//  Created by yenyen on 12/12/2022.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var txtTinh: UITextField!
    @IBOutlet weak var txtHuyen: UITextField!
    @IBOutlet weak var txtXa: UITextField!
    @IBOutlet weak var txtFullName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPhoneNumber: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var errorEmail: UILabel!
    @IBOutlet weak var errorPassword: UILabel!
    @IBOutlet weak var errorPhoneNumber: UILabel!
    
    let Villages = ["Việt Tiến","Thượng Lan","Bình Mỹ","Phú Hoà Đông"]
    let Districts = ["Việt Yên","Củ Chi"]
    let Provinces = ["TP Hồ Chí Minh","Bắc Giang"]
    
    var villagePickerView = UIPickerView()
    var districtPickerView = UIPickerView()
    var provincePickerView = UIPickerView()
    
    @IBOutlet weak var btnSignUp: UIButton!
    @IBAction func emailChanged(_ sender: Any) {
    }
    
    @IBAction func passwordChanged(_ sender: Any) {
    }
    
    @IBAction func phoneNumberChanged(_ sender: Any) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.txtFullName.delegate = self
        
        
        txtXa.inputView = villagePickerView
        txtHuyen.inputView = districtPickerView
        txtTinh.inputView = provincePickerView
        
        txtXa.placeholder = "Select "
        txtHuyen.placeholder = "Select Districts"
        txtTinh.placeholder = "Select Provinces"
        
//        txtXa.textAlignment = .center
//        txtHuyen.textAlignment = .center
//        txtTinh.textAlignment = .center
        
        villagePickerView.delegate = self
        villagePickerView.dataSource = self
        
        districtPickerView.delegate = self
        districtPickerView.dataSource = self
        
        provincePickerView.delegate = self
        provincePickerView.dataSource = self
        
        villagePickerView.tag = 1
        districtPickerView.tag = 2
        provincePickerView.tag = 3
    }
    //TextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return txtFullName.resignFirstResponder()
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
   
     
    }
extension ViewController: UIPickerViewDataSource,UIPickerViewDelegate{
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        switch pickerView.tag{
        case 1:
            return Villages.count
        case 2:
            return Districts.count
        case 3:
            return Provinces.count
        default:
            return 1
        }
      
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        switch pickerView.tag {
        case 1:
            return Villages[row]
        case 2:
            return Districts[row]
        case 3:
            return Provinces[row]
        default:
            return "Data not found"
        
        }
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        switch pickerView.tag {
        case 1:
            txtXa.text = Villages[row];
            txtXa.resignFirstResponder();
        case 2:
            txtHuyen.text = Districts[row];
            txtHuyen.resignFirstResponder();
        case 3:
            txtTinh.text = Provinces[row];
            txtTinh.resignFirstResponder();
        default:
            return
        
        }

    }
    func resetForm(){
        btnSignUp.isEnabled = false
        
        errorEmail.isHidden = false
        errorPassword.isHidden = false
        errorPhoneNumber.isHidden = false
        
        errorEmail.text = "Required"
        errorPassword.text = "Required"
        errorPhoneNumber.text = "Required"
        
        txtEmail.text = ""
        txtPassword.text = ""
        txtPhoneNumber.text = ""
    }
    

}

