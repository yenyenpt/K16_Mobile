//
//  ViewController.swift
//  Message5
//
//  Created by yenyen on 09/11/2022.
//

import UIKit
import MessageKit
import InputBarAccessoryView

class ViewController:MessagesViewController,MessagesDataSource,MessagesLayoutDelegate,MessagesDisplayDelegate,InputBarAccessoryViewDelegate {
    var message : [ChatMessage] = []
    let yen = sender(senderId: "ph34", displayName: "yen")

    override func viewDidLoad() {
        super.viewDidLoad()
        messagesCollectionView.messagesDataSource = self
        messagesCollectionView.messagesLayoutDelegate = self
        messagesCollectionView.messagesDisplayDelegate = self
        messagesCollectionView.delegate = self
       
    }
    var currentSender: SenderType{
        return yen
    }
    
    func messageForItem(at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> MessageType {
        return message[indexPath.section]
    }
    
    func numberOfSections(in messagesCollectionView: MessagesCollectionView) -> Int {
        return message.count
    }
    func inputBar(_ inputBar: InputBarAccessoryView, didPressSendButtonWith text: String) {
        let newMessage = ChatMessage(sender: currentSender, messageId: UUID().uuidString, sentDate: Date(), kind:.text(text))
        message.append(newMessage)
        inputBar.inputTextView.text = ""
        messagesCollectionView.reloadData()
    }
    


}
struct sender : SenderType{
    var senderId: String
    
    var displayName: String
    
    
}
struct ChatMessage: MessageType{
    var sender: SenderType
    
    var messageId: String
    
    var sentDate: Date
    
    var kind: MessageKind
    
    
}

