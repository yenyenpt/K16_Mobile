//
//  ViewController.swift
//  Message3
//
//  Created by yenyen on 08/11/2022.
//

import UIKit
import MessageKit
import InputBarAccessoryView

class ViewController: MessagesViewController,MessagesDataSource,MessagesLayoutDelegate,MessagesDisplayDelegate,InputBarAccessoryViewDelegate {
    var message : [ChatMessage] = []
    let yen = Sender(senderId: "ph29", displayName: "yenpt")
    

    override func viewDidLoad() {
        super.viewDidLoad()
        messagesCollectionView.messagesLayoutDelegate = self
        messagesCollectionView.messagesDataSource = self
        messagesCollectionView.messagesDisplayDelegate = self
        messageInputBar.delegate = self
        
    }
    var currentSender: SenderType {
        return yen
    }
        
    
    func messageForItem(at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> MessageType {
        return message[indexPath.section]
    }
    
    func numberOfSections(in messagesCollectionView: MessagesCollectionView) -> Int {
        return message.count
    }
    func inputBar(_ inputBar: InputBarAccessoryView, didPressSendButtonWith text: String) {
        let newMessage = ChatMessage(sender: currentSender, messageId: UUID().uuidString, sentDate: Date(), kind: .text(inputBar.inputTextView.text))
        message.append(newMessage)
        inputBar.inputTextView.text = ""
        messagesCollectionView.reloadData()
    }
    


}
struct Sender: SenderType{
    var senderId: String
    var displayName: String
}
struct ChatMessage: MessageType{
    var sender: SenderType
    
    var messageId: String
    
    var sentDate: Date
    
    var kind: MessageKind
}

