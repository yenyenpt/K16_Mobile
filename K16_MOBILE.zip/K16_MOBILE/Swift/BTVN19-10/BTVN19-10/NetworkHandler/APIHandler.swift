//
//  APIHandler.swift
//  BTVN19-10
//
//  Created by Dương Văn Cường on 21/10/2022.
//

import Foundation
import Alamofire

class APIHandler {
    let BASE_API_URL = "https://632c7f491aabd837399d7c73.mockapi.io/Friends"
    func getFriends(completion: @escaping (Friends) -> ()) {
        AF.request("\(BASE_API_URL)", method: .get).responseDecodable(of: Friends.self) { (response) in
            
            if let friendsResponse = response.value {
                completion(friendsResponse)
            }
        }
    }
    

    
    func postFriend(_bodyRequest: Friend) {
        AF.request("\(BASE_API_URL)", method: .post, parameters: _bodyRequest).responseDecodable(of: Friend.self) { (response) in
        }
    }
    
    func deleteFriend(_id: String){
            AF.request("\(BASE_API_URL)/\(_id)", method: .delete).responseDecodable(of: Friend.self) { (response) in
            }
    }
    
    func putFriend(_id: String, friend: Friend){
        AF.request("\(BASE_API_URL)/\(_id)", method: .put, parameters: friend).responseDecodable(of: Friend.self) { (response) in
        }
    }
}




