//
//  ViewController.swift
//  MessageBuoi2
//
//  Created by yenyen on 08/11/2022.
//

import UIKit
//MARK: Bước 1: import mesageKit
import MessageKit
//MARK: Bước 8:import
import InputBarAccessoryView


//MARK: Bước 2:tạo các view..
class ViewController: MessagesViewController,MessagesDataSource,MessagesDisplayDelegate,MessagesLayoutDelegate,InputBarAccessoryViewDelegate {
    
    //MARK: Bước 4:Tạo mảng
    var message: [ChatMessage] = []
    //MARK: Bước 5: Khởi tạo 1 Sender kiểu Sender
    let yen = Sender(senderId: "yenpt", displayName: "YenPham")

    override func viewDidLoad() {
        super.viewDidLoad()
        //MARK: Bước 6:Khai báo các thuộc tính
        messagesCollectionView.messagesDataSource = self
        messagesCollectionView.messagesLayoutDelegate = self
        messagesCollectionView.messagesDisplayDelegate = self
        messageInputBar.delegate = self
       
    }
    //MARK: Bước 7:Dungf  3 ham
    var currentSender: SenderType {
        return yen
    }
    
    func messageForItem(at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> MessageType {
        return message[indexPath.section]
    }
    
    func numberOfSections(in messagesCollectionView: MessagesCollectionView) -> Int {
        return message.count
    }
    
    //MARK:Bước 9 tao doi tuong kieu [charMessage]
    func inputBar(_ inputBar: InputBarAccessoryView, didPressSendButtonWith text: String) {
        let currentMessage = ChatMessage(sender: yen, messageId: UUID().uuidString, sentDate: Date(), kind: .text(text))
        message.append(currentMessage)
        messagesCollectionView.reloadData()
        inputBar.inputTextView.text = ""
    }
}
//MARK:Bước 3 Tạo hai struct
struct Sender: SenderType{
    var senderId: String
    var displayName: String
}
struct ChatMessage: MessageType{
    var sender: SenderType
    var messageId: String
    var sentDate: Date
    var kind: MessageKind
}


