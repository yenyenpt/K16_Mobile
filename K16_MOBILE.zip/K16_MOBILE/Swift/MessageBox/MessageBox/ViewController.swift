//
//  ViewController.swift
//  MessageBox
//
//  Created by yenyen on 08/11/2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }


}

