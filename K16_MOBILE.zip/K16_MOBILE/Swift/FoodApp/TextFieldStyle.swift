//
//  TextFieldStyle.swift
//  FoodApp
//
//  Created by chuottp on 15/09/2022.
//

import UIKit

class TextFieldStyle: UITextField {
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func borderRect(forBounds bounds: CGRect) -> CGRect {
        // helu
    }
    

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
