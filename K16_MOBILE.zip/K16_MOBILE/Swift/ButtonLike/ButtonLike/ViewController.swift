//
//  ViewController.swift
//  ButtonLike
//
//  Created by yenyen on 12/10/2022.
//

import UIKit
import Alamofire
import Kingfisher


class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tblButtonLike: UITableView!
    //Bước 1
    var likeDictionary : [Int:Bool] = [:]
    var Friends: likeDictionaryInfos = []
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblButtonLike.delegate = self
        tblButtonLike.dataSource = self
        tblButtonLike.register(UINib(nibName: "ButtonLikeTableViewCell", bundle: nil), forCellReuseIdentifier: "ButtonLike")
        getInfosFromAPI ()
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 500
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblButtonLike.dequeueReusableCell(withIdentifier: "ButtonLike", for: indexPath) as! ButtonLikeTableViewCell
        cell.LikeButton.tag = indexPath.row
        cell.LikeButton.addTarget(self, action: #selector(likeAction), for: .touchUpInside)
        if let isButtonLiked = likeDictionary[indexPath.row] {
            if isButtonLiked {
                cell.LikeButton.setImage(UIImage(named: "poweron"), for: .normal)
            }
        }
        
        return cell
    }
    //Bước 2
    
    @objc func likeAction (_ sender: UIButton){
        if let isButtonLiked  = likeDictionary[sender.tag]
        {
            likeDictionary[sender.tag] = !isButtonLiked
        } else {
            likeDictionary[sender.tag] = true
            
        }
        tblButtonLike.reloadData()
    }
    func getInfosFromAPI () {
        AF.request("https://632c7f1a1aabd837399d7808.mockapi.io/Info").responseDecodable (of: likeDictionaryInfos.self) {
            responseData in
            //            debugPrint(responseData)
            if let infosData = responseData.value {
                self.Friends = infosData
                self.tblButtonLike.reloadData()
                
                
                
                
            }
        }
    }
}


