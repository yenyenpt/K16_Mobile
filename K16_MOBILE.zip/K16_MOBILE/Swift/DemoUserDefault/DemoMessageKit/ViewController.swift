//
//  ViewController.swift
//  DemoMessageKit
//
//  Created by yenyen on 08/11/2022.
//

import UIKit

class ViewController: UIViewController {
    //MARK: Khai báo
    @IBOutlet weak var lblUser: UILabel!
    let saveDefault = UserDefaults.standard

    override func viewDidLoad() {
        super.viewDidLoad()
        saveUserProfile()
        
    }
    //MARK: tao ham luu
    func saveUserProfile(){
        saveDefault.set("Pham Thi Yen", forKey: "name")
        saveDefault.set("08/12/2003", forKey: "date")
        
    }
    //MARK: tao ham lay du lieu
    func getData(){
        let info = saveDefault.string(forKey: "name")
        lblUser.text = info
    }
    

    @IBAction func btnHienThi(_ sender: Any) {
        getData()
    }
    
}

