//
//  DetaiViewController.swift
//  CorrectQLSV
//
//  Created by yenyen on 13/09/2022.
//

import UIKit

class DetaiViewController: UIViewController {

    @IBOutlet weak var lblLable: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblPhoneNumber: UILabel!
    var fullName: String = ""
    var student: Student?
  
    override func viewDidLoad() {
        super.viewDidLoad()
        lblLable.text = student?.name
        lblEmail.text = student?.email
        lblPhoneNumber.text = student?.phoneNumber
        self.navigationItem.title = student?.name
        
        let rightBarButton = UIBarButtonItem(title: "Seach",image: nil, primaryAction: nil, menu: nil)
        self.navigationItem.rightBarButtonItem = rightBarButton
        
        let leftBarButton = UIBarButtonItem(title: "Back",image: nil, primaryAction: nil, menu: nil)
        leftBarButton.target = self
        leftBarButton.action = #selector(barButtonAction)
        self.navigationItem.leftBarButtonItem = leftBarButton
        
      
        
        // Do any additional setup after loading the view.
    }
    @objc func barButtonAction(){
        self.navigationController?.popViewController(animated: true)
        
    }
    

   @IBAction func GotoC(_ sender: UIButton) {
        let detailVC = self.storyboard?.instantiateViewController(withIdentifier: "CViewController") as! CViewController
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
    
   
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
