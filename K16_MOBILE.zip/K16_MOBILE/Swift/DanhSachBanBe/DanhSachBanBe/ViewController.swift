//
//  ViewController.swift
//  DanhSachBanBe
//
//  Created by yenyen on 29/09/2022.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var tblFiend: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblFiend.delegate = self
        tblFiend.dataSource = self
        
        tblFiend.register(UINib(nibName: "FriendTableViewCell", bundle: nil), forCellReuseIdentifier: "cellFriendIdentifier")
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 100
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblFiend.dequeueReusableCell(withIdentifier: "cellFriendIdentifier", for: indexPath) as! FriendTableViewCell
        cell.lblIndex.text = "team \(indexPath.row+1)"
        return cell
    }

}

