//
//  FriendTableViewCell.swift
//  DanhSachBanBe
//
//  Created by yenyen on 29/09/2022.
//

import UIKit
import Kingfisher
import Alamofire

class FriendTableViewCell: UITableViewCell, UICollectionViewDelegate, UICollectionViewDataSource {
    var friends : Friend = []
    
    @IBOutlet weak var lblIndex: UILabel!
    @IBOutlet weak var cltViewFriend: UICollectionView!
    override func awakeFromNib() {
        super.awakeFromNib()
        cltViewFriend.delegate = self
        cltViewFriend.dataSource = self
        
        cltViewFriend.register(UINib(nibName: "FriendCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "collectionIdentifier")
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.itemSize = CGSize(width: 200, height: 82)
        cltViewFriend.collectionViewLayout = layout
        getFriendFromIPT()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return friends.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let currentFriend = friends[indexPath.row]
        let cell = cltViewFriend.dequeueReusableCell(withReuseIdentifier: "collectionIdentifier", for: indexPath) as! FriendCollectionViewCell
        cell.lblFriendName.text = currentFriend.name
        let urlAvatar = URL(string: currentFriend.avatar)
        cell.imgAvatar.kf.setImage(with: urlAvatar)
        
        
        
        return cell
    }
    func getFriendFromIPT(){
        AF.request("https://6333cb15433198e79dc94f71.mockapi.io/Person",method: .get).responseDecodable(of: Friend.self){
            reponseData in
            if let friendData = reponseData.value{
                self.friends = friendData
                self.cltViewFriend.reloadData()
            }
        }
    }
    

    
    

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }
    
}
