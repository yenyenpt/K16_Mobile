
//
//  FriendModel.swift
//  DanhSachBanBe
//
//  Created by yenyen on 30/09/2022.
//

import Foundation

struct FriendModel: Decodable {
    let createdAt, name: String
    let avatar: String
    let id: String
}

typealias Friend = [FriendModel]

