//
//  FriendCollectionViewCell.swift
//  DanhSachBanBe
//
//  Created by yenyen on 30/09/2022.
//

import UIKit

class FriendCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var lblFriendName: UILabel!
    @IBOutlet weak var imgAvatar: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
