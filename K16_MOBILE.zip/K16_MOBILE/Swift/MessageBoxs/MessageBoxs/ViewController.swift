//
//  ViewController.swift
//  MessageBoxs
//
//  Created by yenyen on 08/11/2022.
//

import UIKit
import MessageKit
import InputBarAccessoryView

class ViewController: MessagesViewController,MessagesDataSource,MessagesLayoutDelegate,MessagesDisplayDelegate,InputBarAccessoryViewDelegate{
    var message : [ChatMessage] = []
    let yen = Sender(senderId: "ph20", displayName: "yen")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        messagesCollectionView.messagesDataSource = self
        messagesCollectionView.messagesDisplayDelegate = self
        messagesCollectionView.messagesLayoutDelegate = self
        messageInputBar.delegate = self
        
        
    }
    var currentSender: SenderType{
        return yen
    }
    
    func messageForItem(at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> MessageType {
        return message[indexPath.section]
    }
    
    func numberOfSections(in messagesCollectionView: MessagesCollectionView) -> Int {
        return message.count
    }
    func inputBar(_ inputBar: InputBarAccessoryView, didPressSendButtonWith text: String) {
        let newMessage = ChatMessage(sender: currentSender, messageId: "1", sentDate: Date(), kind: .text(inputBar.inputTextView.text))
        message.append(newMessage)
        inputBar.inputTextView.text = ""
        messagesCollectionView.reloadData()
    }
    


}

struct Sender : SenderType{
    var senderId: String
    var displayName: String
}

public struct ChatMessage : MessageType{
    public var sender: SenderType
    
    public var messageId: String
    
    public var sentDate: Date
    
    public var kind: MessageKind
    
    
    
    
}

