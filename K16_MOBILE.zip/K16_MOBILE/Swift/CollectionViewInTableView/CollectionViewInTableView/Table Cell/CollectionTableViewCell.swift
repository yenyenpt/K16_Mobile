//
//  CollectionTableViewCell.swift
//  CollectionViewInTableView
//
//  Created by yenyen on 29/09/2022.
//

import UIKit

class CollectionTableViewCell:UITableViewCell, UICollectionViewDataSource,UICollectionViewDelegate {
    
    
    
    static let identifier = "CollectionTableViewCell"
    static func nib() -> UINib{
        return UINib(nibName: "CollectionTableViewCell", bundle: nil)
    }
    @IBOutlet var collectionView: UICollectionView!
    override func awakeFromNib() {
        super.awakeFromNib()
        collectionView.register(CollectionTableViewCell.nib(), forCellWithReuseIdentifier: "CollectionTableViewCell.identifier")
        collectionView.delegate = self
        collectionView.dataSource = self
    }
   
    var models = [Model]()
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }
    //collection
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MyCollectionView.identifier",for: indexPath) as! MyCollectionViewCell
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return models.count
    }
    func collectionView(_ collectionView: UICollectionView,layout CollectionViewLayout: UICollectionViewLayout,sizeForItemAt index: IndexPath) -> CGSize {
        return CGSize(width: 250, height: 250)
        <#code#>
    }
}
    
    

