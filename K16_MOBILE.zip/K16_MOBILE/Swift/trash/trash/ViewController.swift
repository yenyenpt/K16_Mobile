//
//  ViewController.swift
//  trash
//
//  Created by protech on 10/22/22.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var imgCenterMarker: UIImageView!
    @IBOutlet weak var lblAddress: UILabel!
    
    let locationManager = CLLocationManager()
    let zoomMeters: Double = 1000
    var previousLocation: CLLocation?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        checkLocationServices()     //Check on launch screen
    }
    
    //MARK: Setup location manager to run
    func setupLocationManager() {
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
    }

    //MARK: Focus and center map view on user location
    func centerViewOnUserLocation() {
        if let location = locationManager.location?.coordinate {
            let region = MKCoordinateRegion.init(center: location, latitudinalMeters: zoomMeters, longitudinalMeters: zoomMeters)
            mapView.setRegion(region, animated: true)
        }
    }
    
    //MARK: Check whether location services on user device is enabled or not
    func checkLocationServices() {
        if CLLocationManager.locationServicesEnabled() {
            setupLocationManager()
            checkLocationAuthorization()
        } else {
            //Show alert to turn location service on
        }
    }
    
    func startTrackingUserLocation() {
        mapView.showsUserLocation = true    //Display a dot on user location
        centerViewOnUserLocation()      //Center map view on user location
        locationManager.startUpdatingLocation()     //Update user location on move
        previousLocation = getCenterLocation(for: mapView)     //Initialize user location
    }
    
    //MARK: Check location authorization
    func checkLocationAuthorization() {
        switch CLLocationManager.authorizationStatus() {
        case .authorizedWhenInUse:
            startTrackingUserLocation()
        case .notDetermined:
            locationManager.requestWhenInUseAuthorization()
        case .restricted:
            break
        case .denied:
            break
        case .authorizedAlways:
            break
        @unknown default:
            break
        }
    }
    
        //MARK: Keep centering on user location while move
        func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
            guard let location = locations.last else { return}
            let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
            let region = MKCoordinateRegion.init(center: center, latitudinalMeters: zoomMeters, longitudinalMeters: zoomMeters)
            mapView.setRegion(region, animated: true)
        }
        
        //MARK: Check location authorization again whenever user change it
        func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
            checkLocationAuthorization()
        }

    func getCenterLocation(for mapView: MKMapView) -> CLLocation {
        let latitude = mapView.centerCoordinate.latitude
        let longtitude = mapView.centerCoordinate.longitude
        
        return CLLocation(latitude: latitude, longitude: longtitude)
    }
    
    func createDirectionsRequest(from coordinate: CLLocationCoordinate2D) -> MKDirections.Request {
        let destinationCoordinate = getCenterLocation(for: mapView).coordinate
        let startingLocation = MKPlacemark(coordinate: coordinate)
        let destination = MKPlacemark(coordinate: destinationCoordinate)
        
        let request = MKDirections.Request()
        request.source = MKMapItem(placemark: startingLocation)
        request.destination = MKMapItem(placemark: destination)
        request.transportType = .automobile
        request.requestsAlternateRoutes = true
        
        return request
        
    }
    
    func getDirections() {
        guard let location = locationManager.location?.coordinate else {
            //Inform user that we don't have their current location
            return
        }
        
        let request = createDirectionsRequest(from: location)
        let directions = MKDirections(request: request)
        
        directions.calculate { [unowned self] (response, error) in
            //Handle error if needed
            guard let response = response else { return } //Show response not available
            
            for route in response.routes {
                //self.mapView.addOverlay(route.polyline)
                self.mapView.setVisibleMapRect(route.polyline.boundingMapRect, animated: true)
            }
        }
    }
    
    
    @IBAction func btnRecenterUserLocationOnPress(_ sender: UIButton) {
        centerViewOnUserLocation()
    }
    
    @IBAction func btnGetDirectionOnPress(_ sender: UIButton) {
        getDirections()
    }
    
    
    //MARK: Do not understand
    func mapView(_ mapView: MKMapView, regionDidChangeAnimated animated: Bool) {
        let center = getCenterLocation(for: mapView)
        let geoCoder = CLGeocoder()
        
        guard let previousLocation = self.previousLocation else { return }

        guard center.distance(from: previousLocation ) > 50 else { return }
        self.previousLocation = center
        
        geoCoder.reverseGeocodeLocation(center) {
            [weak self] (placemarks, error) in
            guard let self = self else { return }
            
            if let _ = error {
                //Show alert
                return
            }
            
            guard let placemark = placemarks?.first else {
                //Show alert
                return
            }
            
            let areaName = placemark.subAdministrativeArea ?? ""
            let cityName = placemark.administrativeArea ?? ""
            
            DispatchQueue.main.async {
                self.lblAddress.text = "\(areaName) - \(cityName)"
            }
        }
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let renderer = MKPolygonRenderer(overlay: overlay as! MKPolyline)
        renderer.strokeColor = .white
        
        return renderer
    }
}


