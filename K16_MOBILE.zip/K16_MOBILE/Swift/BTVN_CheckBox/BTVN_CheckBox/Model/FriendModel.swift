//
//  FriendModel.swift
//  BTVN_CheckBox
//
//  Created by Thanh Dat on 02/10/2022.
//

import Foundation
struct FriendModel: Decodable {
    let name: String
    let avatar: String
    let id: String
}

typealias Friend = [FriendModel]
