//
//  FriendsTableViewCell.swift
//  BTVN_CheckBox
//
//  Created by Thanh Dat on 02/10/2022.
//

import UIKit

class FriendsTableViewCell: UITableViewCell {

    @IBOutlet weak var imgFriend: UIImageView!
    @IBOutlet weak var lblFriendName: UILabel!
    @IBOutlet weak var btnCheckBox: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        btnCheckBox.setImage(UIImage(named: "check"), for: .normal)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    //b4 phòng trường hợp bị lặp cell thì ta luôn xét cell = uncheck
    override func prepareForReuse() {
        btnCheckBox.setImage(UIImage(named: "check"), for: .normal)
    }
}
