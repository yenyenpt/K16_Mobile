//
//  ViewController.swift
//  BTVN_CheckBox
//
//  Created by Thanh Dat on 02/10/2022.
//

import UIKit
import Kingfisher
import Alamofire

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tblFriend: UITableView!
    @IBOutlet weak var btnCheckBoxAll: UIButton!
    
    var friends: Friend = []
    //b1:tạo 1 dic
    var friendsDict: [Int: Bool] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblFriend.delegate = self
        tblFriend.dataSource = self
        
        btnCheckBoxAll.setImage(UIImage(named: "check"), for: .normal)
        tblFriend.register(UINib(nibName: "FriendsTableViewCell", bundle: nil), forCellReuseIdentifier: "cellIdentifier")
        getFriendFromAPI()
        
        btnCheckBoxAll.addTarget(self, action: #selector(checkBoxAllAction(_:)), for: .touchUpInside)
    }
    
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return friends.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblFriend.dequeueReusableCell(withIdentifier: "cellIdentifier", for: indexPath) as! FriendsTableViewCell
        let currentFriend = friends[indexPath.row]
        
        let URLAvatar = URL(string: currentFriend.avatar)
        cell.imgFriend.kf.setImage(with: URLAvatar)
    
        cell.lblFriendName.text = currentFriend.name
        
        cell.btnCheckBox.tag = indexPath.row
        cell.btnCheckBox.addTarget(self, action: #selector(checkBoxAction(_:)), for: .touchUpInside)
        
        //b3: kiểm tra trạng thái của checkbox đã từng được lưu hay chưa ,nếu trạng thái = true thf xét img = checked
        if let isBtnChecked = friendsDict[indexPath.row] {
            if isBtnChecked {
                cell.btnCheckBox.setImage(UIImage(named: "checked"), for: .normal)
            }
        }
        
        return cell
    }
    
    
   
    
    //MARK: Bước 2: cập nhật lại - bắt skien nút like
    @objc func checkBoxAction(_ sender: UIButton) {
        print("sender \(sender.tag)")
        //nếu đã tưng được lưu trong từ điển thì câp nhật lại trạng thái bằng phủ định của nó
        if let isChecked = friendsDict[sender.tag] {
            friendsDict[sender.tag] = !isChecked
            
        } else {
            friendsDict[sender.tag] = true
        }
        
        //b2 nếu cout = fiends.count => duyệt vòng for để gán toàn bộ frienđict = false
        let isCheckedAll = isCheckedAllFriend()
        
        if isCheckedAll {
            btnCheckBoxAll.setImage(UIImage(named: "checkedAll"), for: .normal)
        } else {
            btnCheckBoxAll.setImage(UIImage(named: "check"), for: .normal)
        }
        
        tblFriend.reloadData()
        
    }
    
    
    
    @objc func checkBoxAllAction(_ sender: UIButton) {
        //b2 nếu cout = fiends.count => duyệt vòng for để gán toàn bộ frienđict = false
        let isCheckedAll = isCheckedAllFriend()
        
        if isCheckedAll {
            btnCheckBoxAll.setImage(UIImage(named: "check"), for: .normal)
        } else {
            btnCheckBoxAll.setImage(UIImage(named: "checkedAll"), for: .normal)
        }
        
        for (index, _) in friends.enumerated() {
            if isCheckedAll {
                friendsDict[index] = false
            } else {
                friendsDict[index] = true
            }
        }
        tblFriend.reloadData()
    }
    
    //b1 ktra tổng số phần tử đc check
    func isCheckedAllFriend() -> Bool {
        var countFriendChecked = 0
        for (index, _) in friends.enumerated() {
            if friendsDict[index] == true {
                countFriendChecked += 1
            }
        }
        return countFriendChecked == friends.count
    }
    
    
    @IBAction func btnTapDelete(_ sender: UIButton) {
       
    }
    
    
    
    func getFriendFromAPI() {
        APIHandler.init().getFriends {
            responseData in
            self.friends = responseData
            self.tblFriend.reloadData()
        }
    }

}

