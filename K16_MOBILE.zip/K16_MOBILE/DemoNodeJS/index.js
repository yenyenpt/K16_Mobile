const express = require('express')
const app = express()
const port = 3000
var bodyParse = require('body-parser')
app.use(express.json())
 


app.get('/', (req, res) => {
  res.send('<h1 style="color:red">Xin chao</h1 > ')
})
app.post('/addfriend',(req,res) => {
    console.log("Da nhan duoc noi dung la: " + req.body.name)
    res.send("Chao buoi toi ban " + req.body.name+ req.body.age+"nhe")
})

app.post('')

app.listen(port)
console.log("Server dang chay cong 3000")
